class Firstmain{
public static void main(String [] args){
First f=new First();
Car c=new Car();
f.display();
System.out.println();
c.display();
c.discount();
}
}
